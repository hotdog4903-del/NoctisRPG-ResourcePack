#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    // FE01FD is reserved for the Hotdog RPG money overlay. Legacy text shadow
    // is one quarter of that RGB value, so both passes receive the same shift.
    bool moneyMain = Color.r > 0.98 && Color.g < 0.02 && Color.b > 0.98;
    bool moneyShadow = Color.r > 0.22 && Color.r < 0.28 && Color.g < 0.02 && Color.b > 0.22 && Color.b < 0.28;
    bool moneyGlyph = moneyMain || moneyShadow;

    if (moneyGlyph) {
        float guiWidth = 2.0 / abs(ProjMat[0][0]);
        float rightEdgeShift = (guiWidth * 0.5) - 212.0;
        gl_Position.x += ((2.0 * rightEdgeShift) / guiWidth) * gl_Position.w;
    }

    // 02FE03 marks advanced-skill held names. Only the bottom HUD rendering
    // pass is raised, so the same name remains aligned inside item tooltips.
    bool raisedNameMain = Color.r < 0.02 && Color.g > 0.98 && Color.b < 0.02;
    bool raisedNameShadow = Color.r < 0.02 && Color.g > 0.22 && Color.g < 0.28 && Color.b < 0.02;
    bool raisedNameGlyph = raisedNameMain || raisedNameShadow;
    float guiHeight = 2.0 / abs(ProjMat[1][1]);
    bool bottomHudText = Position.y > guiHeight - 82.0;
    if (raisedNameGlyph && bottomHudText) {
        float upwardShift = 34.0;
        gl_Position.y += ((2.0 * upwardShift) / guiHeight) * gl_Position.w;
    }

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

    vec4 lightColor = texelFetch(Sampler2, UV2 / 16, 0);
    if (moneyMain) {
        vertexColor = vec4(1.0, 1.0, 1.0, Color.a) * lightColor;
    } else if (moneyShadow) {
        vertexColor = vec4(0.25, 0.25, 0.25, Color.a) * lightColor;
    } else if (raisedNameMain) {
        vertexColor = vec4(0.36, 1.0, 0.36, Color.a) * lightColor;
    } else if (raisedNameShadow) {
        vertexColor = vec4(0.09, 0.25, 0.09, Color.a) * lightColor;
    } else {
        vertexColor = Color * lightColor;
    }
    texCoord0 = UV0;
}
